--1. List all the names of Students who are pursuing a BSc (Bachelors of Science) along with their current Grades, and group them by Course Descriptions.

select xmlroot(
	xmlelement("BSc_Students", 
		xmlagg(xmlelement("Course", xmlattributes(g.cID.cDescription as "C_Desc"),
			xmlagg(xmlelement("Student",
				xmlelement("First_Name", g.userID.fname),
				xmlelement("Last_Name", g.userID.lname),
				xmlelement("Grade", g.grade)
				)
			)
		))).extract('/*'),
	version '1.0', standalone yes
	)
as BSc_Student_List
from table_grade g 
where g.userID.degree = 'BSc'
group by g.cID.cDescription;

--2. List all the registered Students' first and last names, along with their membership start date, total membership length to date, and current discount rate, who made payments in February. 

select xmlroot(
	xmlelement("Current_Discounts",
		xmlagg(xmlelement("Membership",xmlattributes(p.userID.userID as "User_ID"),
			xmlelement("Student",xmlattributes(p.userID.uniStudentNo as "SN"),
				xmlforest(p.userID.fname as "First_Name",p.userID.lname as "Last_Name",p.userID.memStart as "Start_Date",p.userID.membershipLength() as "Membership_Length")
				),
			xmlelement("Discount_Rate",p.userID.findDiscountRate(p.userID.membershipLength())
			)
		))).extract('/*'),
	version '1.0', standalone yes
	)
as Member_Chart
from table_payment p
where p.payDate > '01-Feb-2018';

--3. List all the details (i.e., Job Title, Company Name, Salary and Job Type) of open job orders that require CSS as a required skill. 

select xmlroot(
	xmlelement("CSS_Jobs",
		xmlagg(xmlelement("Open_Jobs",
			xmlagg(xmlelement("Job_Summary",xmlattributes(j.jID.jID as "jID"),
				xmlelement("Job_Profile",
					xmlelement("Job_Title",j.jID.jobTitle),
					xmlelement("Company",j.jID.company),
					xmlelement("Skill_Required",j.skillID.skillName)
					),
				xmlelement("Job_Package",
					xmlelement("Job_Salary",j.jID.salary),
					xmlelement("Job_type",j.jID.jobType)
					)
				)
			)
		))).extract('/*'),
	version '1.0', standalone yes
	)
as Open_CSS_Jobs
from table_jobSkill j
where j.jID.jstatus.status = 'open' and j.skillID.skillName = 'CSS'
group by j.jID.jID;

--4. List the salary of all the Recruiters who posted Jobs from Apple.



--5. List the names of all the Students who have taken ITEC Courses along with their respective grades. 



--6. List the names of all the students who have taken the Mobile Programming course. 



--7. List the names of Recruiters who have closed Job Orders.



--8. List the names of Recruiters who have open Job Orders.



--9. Identify which Job Orders belong to Dave Brown.



--10. List the names of Students who have received an A+ in any course and identify their Degree and Field of Study.