
/*GROUP BY: List the technical skills and the courses that develop that skill.
Group by technical skills.*/

select
		xmlroot (
			xmlelement ("skillList",
				xmlagg(xmlelement("technicalSkill", xmlattributes(cs.skillid.skillName),
				xmlagg(xmlelement("CourseList",
					xmlattributes(cs.cid.cid as "cID"),
					xmlforest(cs.cid.cName as "courseName", cs.cid.cdescription as "courseDescription")
))))).extract('/*'), version '1.0', standalone yes)
as Skills_List
from table_courseSkill cs
group by cs.skillid.skillName; 



/*List the students that are qualified for “Software Developer” 
job, and the courses that they have taken.*/

select 
	xmlroot(
		xmlelement("QualifiedList",
				xmlagg(xmlelement("student", xmlattributes(e.userid.unistudentno as "studentNo"),
					xmlelement("firstName", e.userid.fname),
					xmlelement("lastName", e.userid.lname),
					xmlelement("CoursesTaken",
						xmlagg(xmlelement("Course", xmlattributes(g.cid.cid as "cID"),
							xmlforest(g.cid.cName as "courseName", 
							g.cid.cdescription as "courseDesc"))
							)
							)
					)
				)).extract('/*'),version '1.0', standalone yes)
as Qualified_List
from table_evaluation e, table_grade g
where e.userid = g.userid and e.jid.jobtitle = 'Software Developer' and percentQualified >=70
group by e.userid.unistudentno, e.userid.lname, e.userid.fname;


/*List the personal information (i.e student number, full name, 
contact info) and education(i.e degree, university start date, 
graduation date,  time left to graduate and grade) of the students 
who completed ITEC3220.*/

select 
	xmlroot(
		xmlelement("CompletedITEC3220",
				xmlagg(xmlelement("student", xmlattributes(g.userid.unistudentno as "studentNo"),
					xmlelement("PersonalInfo",
							xmlforest(g.userid.fname||' '||g.userid.lname as "Name",
							g.userid.phone as "PhoneNumber",
							g.userid.email as "Email")),
					xmlelement("Education",
							xmlforest(g.userid.degree as "Degree",
							g.userid.unistart as "uniStartDate",
							g.userid.calctimelefttograduate()||' months' as "timeLeftToGrad",
							g.userid.graddate as "gradDate",
							g.grade as "ITEC3220Grade"))
							)
					))
				.extract('/*'),version '1.0', standalone yes)
as Qualified_List
from table_grade g
where g.cid.cname = 'ITEC3220';