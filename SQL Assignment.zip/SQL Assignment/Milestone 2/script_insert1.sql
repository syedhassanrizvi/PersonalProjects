-- table_student
INSERT INTO table_student VALUES (student_t('1', 'John', 'Rodriguez', '25 Steeles Ave', '416-454-1212', 'john@gmail.com', 'S', '10-Nov-2017', '214587896', '1-Sep-2016', '1-May-2020', 'BSc', 'Software Engineering'));
INSERT INTO table_student VALUES (student_t('2', 'Megan', 'Williams', '58 Finch Ave', '416-854-8979', 'megan@live.com', 'S', '24-Jan-2016',  '216879878', '1-Jan-2017', '31-Dec-2020', 'BSc', 'Computer Science'));
INSERT INTO table_student VALUES (student_t('3', 'Charlie', 'Smith', '882 Yonge St', '647-878-5444', 'smith@gmail.com', 'S', '3-Mar-2017',  '213444578', '1-Sep-2015', '1-May-2019', 'Bcom', 'Information Technology'));
INSERT INTO table_student VALUES (student_t('4', 'Emily', 'Reese', '120 Mills Rd', '905-221-2487', 'emily@gmail.com', 'S', '12-Jun-2017', '212334777', '1-Sep-2014', '31-Dec-2019', 'BA', 'Information Technology'));
-- table_recruiter
INSERT INTO table_recruiter VALUES (recruiter_t('200', 'Dave', 'Brown', '12 Yonge St', '415-989-8874', 'brown@yuhu.com', 'R', '1-Jan-2015', '123458', 40000));
INSERT INTO table_recruiter VALUES (recruiter_t('201', 'Cathy', 'Green', '58 Keele St', '416-989-7878', 'green@yuhu.com', 'R', '25-May-2010', '214455', 55000));
INSERT INTO table_recruiter VALUES (recruiter_t('202', 'Sarah', 'Fox', '25 Richmond St', '415-989-1245', 'fox@yuhu.com', 'R', '24-Feb-2017', '454864', 30000));
-- table_payment
INSERT INTO table_payment VALUES (payment_t ('1', 100, '22-Jan-2018', 'MC', (SELECT ref(s) FROM table_student s WHERE s.userID = '1')));
INSERT INTO table_payment VALUES (payment_t ('2', 30, '28-Feb-2018', 'Visa', (SELECT ref(s) FROM table_student s WHERE s.userID = '1')));
INSERT INTO table_payment VALUES (payment_t ('3', 60, '15-Feb-2018', 'MC', (SELECT ref(s) FROM table_student s WHERE s.userID = '2')));
INSERT INTO table_payment VALUES (payment_t ('4', 75, '30-Jan-2018', 'MC', (SELECT ref(s) FROM table_student s WHERE s.userID = '3')));
INSERT INTO table_payment VALUES (payment_t ('5', 40, '28-Feb-2018', 'Amex', (SELECT ref(s) FROM table_student s WHERE s.userID = '3')));
INSERT INTO table_payment VALUES (payment_t ('6', 120, '1-Jan-2018', 'Visa', (SELECT ref(s) FROM table_student s WHERE s.userID = '4')));
INSERT INTO table_payment VALUES (payment_t ('7', 100, '20-Feb-2018', 'Visa', (SELECT ref(s) FROM table_student s WHERE s.userID = '4')));
-- table_course
INSERT INTO table_course VALUES (course_t('1001', 'ITEC2610', 'Object-Oriented Programming'));
INSERT INTO table_course VALUES (course_t('1002', 'ITEC3020', 'Web Technologies'));
INSERT INTO table_course VALUES (course_t('1003', 'ITEC2600', 'Analytical Programming'));
INSERT INTO table_course VALUES (course_t('1004', 'ITEC3220', 'Database Systems'));
INSERT INTO table_course VALUES (course_t('1005', 'EECS1012', 'Net-Centric Computing'));
INSERT INTO table_course VALUES (course_t('1006', 'EECS1021', 'Object-Oriented Programming'));
INSERT INTO table_course VALUES (course_t('1007', 'EECS1022', 'Mobile Programming'));
-- table_technicalSkill
INSERT INTO table_technicalSkill VALUES (technicalSkill_t('2001', 'Java'));
INSERT INTO table_technicalSkill VALUES (technicalSkill_t('2002', 'HTML'));
INSERT INTO table_technicalSkill VALUES (technicalSkill_t('2003', 'CSS'));
INSERT INTO table_technicalSkill VALUES (technicalSkill_t('2004', 'JavaScript'));
INSERT INTO table_technicalSkill VALUES (technicalSkill_t('2005', 'PHP'));
INSERT INTO table_technicalSkill VALUES (technicalSkill_t('2006', 'Matlab'));
INSERT INTO table_technicalSkill VALUES (technicalSkill_t('2007', 'SQL'));
INSERT INTO table_technicalSkill VALUES (technicalSkill_t('2008', 'Android'));
INSERT INTO table_technicalSkill VALUES (technicalSkill_t('2009', 'C'));
INSERT INTO table_technicalSkill VALUES (technicalSkill_t('2010', 'Python'));
-- table_courseSkill
INSERT INTO table_courseSkill VALUES (courseSkill_t ('3001', (SELECT REF(c) FROM table_course c WHERE c.cID = '1001'), (SELECT REF(t) FROM table_technicalSkill t WHERE t.skillID = '2001')));
INSERT INTO table_courseSkill VALUES (courseSkill_t ('3002', (SELECT REF(c) FROM table_course c WHERE c.cID = '1002'), (SELECT REF(t) FROM table_technicalSkill t WHERE t.skillID = '2002')));
INSERT INTO table_courseSkill VALUES (courseSkill_t ('3003', (SELECT REF(c) FROM table_course c WHERE c.cID = '1002'), (SELECT REF(t) FROM table_technicalSkill t WHERE t.skillID = '2003')));
INSERT INTO table_courseSkill VALUES (courseSkill_t ('3004', (SELECT REF(c) FROM table_course c WHERE c.cID = '1002'), (SELECT REF(t) FROM table_technicalSkill t WHERE t.skillID = '2004')));
INSERT INTO table_courseSkill VALUES (courseSkill_t ('3005', (SELECT REF(c) FROM table_course c WHERE c.cID = '1002'), (SELECT REF(t) FROM table_technicalSkill t WHERE t.skillID = '2005')));
INSERT INTO table_courseSkill VALUES (courseSkill_t ('3006', (SELECT REF(c) FROM table_course c WHERE c.cID = '1003'), (SELECT REF(t) FROM table_technicalSkill t WHERE t.skillID = '2006')));
INSERT INTO table_courseSkill VALUES (courseSkill_t ('3007', (SELECT REF(c) FROM table_course c WHERE c.cID = '1004'), (SELECT REF(t) FROM table_technicalSkill t WHERE t.skillID = '2007')));
INSERT INTO table_courseSkill VALUES (courseSkill_t ('3008', (SELECT REF(c) FROM table_course c WHERE c.cID = '1005'), (SELECT REF(t) FROM table_technicalSkill t WHERE t.skillID = '2002')));
INSERT INTO table_courseSkill VALUES (courseSkill_t ('3009', (SELECT REF(c) FROM table_course c WHERE c.cID = '1005'), (SELECT REF(t) FROM table_technicalSkill t WHERE t.skillID = '2003')));
INSERT INTO table_courseSkill VALUES (courseSkill_t ('3010', (SELECT REF(c) FROM table_course c WHERE c.cID = '1005'), (SELECT REF(t) FROM table_technicalSkill t WHERE t.skillID = '2004')));
INSERT INTO table_courseSkill VALUES (courseSkill_t ('3011', (SELECT REF(c) FROM table_course c WHERE c.cID = '1005'), (SELECT REF(t) FROM table_technicalSkill t WHERE t.skillID = '2005')));
INSERT INTO table_courseSkill VALUES (courseSkill_t ('3012', (SELECT REF(c) FROM table_course c WHERE c.cID = '1005'), (SELECT REF(t) FROM table_technicalSkill t WHERE t.skillID = '2009')));
INSERT INTO table_courseSkill VALUES (courseSkill_t ('3013', (SELECT REF(c) FROM table_course c WHERE c.cID = '1006'), (SELECT REF(t) FROM table_technicalSkill t WHERE t.skillID = '2001')));
INSERT INTO table_courseSkill VALUES (courseSkill_t ('3014', (SELECT REF(c) FROM table_course c WHERE c.cID = '1007'), (SELECT REF(t) FROM table_technicalSkill t WHERE t.skillID = '2008')));
INSERT INTO table_courseSkill VALUES (courseSkill_t ('3015', (SELECT REF(c) FROM table_course c WHERE c.cID = '1006'), (SELECT REF(t) FROM table_technicalSkill t WHERE t.skillID = '2010')));
INSERT INTO table_courseSkill VALUES (courseSkill_t ('3016', (SELECT REF(c) FROM table_course c WHERE c.cID = '1002'), (SELECT REF(t) FROM table_technicalSkill t WHERE t.skillID = '2010')));