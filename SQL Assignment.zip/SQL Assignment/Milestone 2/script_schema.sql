--Script file demonstrating SQL statements execution for logical schema
--Create Types
CREATE OR REPLACE TYPE user_t AS OBJECT ( userID VARCHAR2(6), fname VARCHAR2(15), lname VARCHAR2(15), address VARCHAR2(30), phone VARCHAR2(12), email VARCHAR2(25), userType VARCHAR2(10), memStart DATE, MEMBER FUNCTION membershipLength RETURN NUMBER, MAP MEMBER FUNCTION oldestSubscriber RETURN DATE) NOT FINAL;
/
CREATE OR REPLACE TYPE student_t UNDER user_t ( uniStudentNo VARCHAR2(15), uniStart DATE, gradDate DATE, degree VARCHAR2(10), fieldOfStudy VARCHAR2(35), MEMBER FUNCTION calcTimeLeftToGraduate RETURN NUMBER, MEMBER FUNCTION findDiscountRate (mlength IN NUMBER) RETURN NUMBER);
/
CREATE OR REPLACE TYPE recruiter_t UNDER user_t (sin VARCHAR2(6), salary NUMBER, MEMBER FUNCTION findSalaryIncreaseRate RETURN NUMBER, MEMBER FUNCTION findIncomeTaxAmount RETURN NUMBER, MEMBER FUNCTION calcNetIncome (taxAmount IN NUMBER) RETURN NUMBER, OVERRIDING MEMBER FUNCTION membershipLength RETURN NUMBER);
/
CREATE OR REPLACE TYPE payment_t AS OBJECT (pID VARCHAR2(4), paymentAmt NUMBER, payDate DATE, payType VARCHAR2(10), userID  REF student_t, MEMBER FUNCTION calcHST RETURN NUMBER);
/
CREATE OR REPLACE TYPE course_t AS OBJECT (cID VARCHAR2(4), cName VARCHAR2(25), cDescription VARCHAR2(50));
/
CREATE OR REPLACE TYPE technicalSkill_t AS OBJECT (skillID VARCHAR2(10), skillName VARCHAR2(30));
/
CREATE OR REPLACE TYPE jobStatus_t AS OBJECT (deadline DATE, status VARCHAR2(10));
/
CREATE OR REPLACE TYPE jobOrder_t AS OBJECT (jID VARCHAR2(4), jobTitle VARCHAR2(30), company VARCHAR2(15), jobType VARCHAR2(10), salary NUMBER, jstatus jobStatus_T, rID REF recruiter_t, MEMBER FUNCTION calcCommission  RETURN NUMBER);
/
CREATE OR REPLACE TYPE grade_t AS OBJECT (gID VARCHAR2(4), grade VARCHAR2(5), userID REF student_t, cID REF course_t);
/
CREATE OR REPLACE TYPE evaluation_t AS OBJECT ( eID VARCHAR2(4), percentQualified NUMBER, userID REF student_t, jID REF jobOrder_t, MEMBER FUNCTION isQualified RETURN NUMBER, ORDER MEMBER FUNCTION moreQualified (eval IN evaluation_t) RETURN INTEGER);
/
CREATE OR REPLACE TYPE jobSkill_t AS OBJECT (jsID VARCHAR2(4), jID REF jobOrder_t, skillID REF technicalSkill_t);
/
CREATE OR REPLACE TYPE courseSkill_t AS OBJECT (csID VARCHAR2(4), cID REF course_t, skillID REF technicalSkill_t);
/
--Create Tables
CREATE TABLE table_student OF student_t (userID PRIMARY KEY);
CREATE TABLE table_recruiter OF recruiter_t (userID PRIMARY KEY);
CREATE TABLE table_payment OF payment_t (pID PRIMARY KEY);
CREATE TABLE table_course OF course_t (cID PRIMARY KEY);
CREATE TABLE table_technicalSkill OF technicalSkill_t (skillID PRIMARY KEY);
CREATE TABLE table_jobOrder OF jobOrder_t (jID PRIMARY KEY);
CREATE TABLE table_grade OF grade_t (gID PRIMARY KEY);
CREATE TABLE table_evaluation OF evaluation_t (eID PRIMARY KEY);
CREATE TABLE table_jobSkill OF jobSkill_t (jsID PRIMARY KEY);
CREATE TABLE table_courseSkill OF courseSkill_t (csID PRIMARY KEY);
/* Create Type Body for Methods
USER SUPERTYPE
METHOD 1: OLDESTSUBSCRIBER METHOD:
Is a map function that orders object by the membership start date of the user's account
*/
CREATE OR REPLACE TYPE BODY user_t AS MAP MEMBER FUNCTION
oldestSubscriber RETURN DATE
IS
BEGIN
RETURN self.memStart;
END;
/*
METHOD 2: MEMBERSHIPLENGTH METHOD
Method takes the membership start date of user and subtracts it from today's date and returns the number of months since user's membership start date.
*/
MEMBER FUNCTION membershipLength RETURN NUMBER
IS
BEGIN
RETURN TRUNC(MONTHS_BETWEEN(SYSDATE, self.memStart));
END;
END;
/ 
/*
STUDENT SUBTYPE
METHOD 3: CALCTIMELEFTTOGRADUATE METHOD
Method subtracts the grauation date from today's date to return the number of months left for student to graduate.
*/
CREATE OR REPLACE TYPE BODY student_t AS MEMBER FUNCTION
calcTimeLeftToGraduate RETURN NUMBER
IS
BEGIN
RETURN TRUNC(MONTHS_BETWEEN(self.gradDate, SYSDATE));
END;
/*
METHOD 4: FINDDISCOUNTRATE METHOD
Method takes in a number as an input parameter (that is obtained from the membershipLength method in user_t) and depending on how long the membership of the user has been, returns a discount rate of 0, 5 or 7 using if-else statements
*/
MEMBER FUNCTION findDiscountRate (mlength IN NUMBER) RETURN NUMBER
IS
discount NUMBER :=0;
BEGIN
IF mlength BETWEEN 12 AND 24 THEN
discount := 5;
ELSIF mlength > 24 THEN
discount := 7;
ELSE
discount := 0;
END IF;
RETURN discount;
END;
END;
/ 
/*
PAYMENT TYPE
METHOD 5: CALCHST METHOD
Method multiplies the payment amount by the HST rate to return the amount of HST of the payment
*/
CREATE OR REPLACE TYPE BODY payment_t AS MEMBER FUNCTION
calcHST RETURN NUMBER
IS
HSTRate NUMBER :=0.13;
BEGIN
RETURN ROUND(self.paymentAmt * HSTRate, 2);
END;
END;
/
/*
JOBORDER TYPE
METHOD 6: CALCCOMMISSION METHOD
Method multiplies the payment amount by the HST rate to return the amount of HST of the payment
*/
CREATE OR REPLACE TYPE BODY jobOrder_t AS MEMBER FUNCTION
calcCommission RETURN NUMBER
IS
commissionRate NUMBER :=0;
BEGIN
IF SELF.salary <30000 THEN
commissionRate := 2;
ELSIF SELF.salary <50000 THEN
commissionRate := 5;
ELSE
commissionRate := 7;
END IF;
RETURN ROUND(SELF.salary*commissionRate/100, 2);
END;
END;
/
/*
EVALUATION TYPE
METHOD 7: MOREQUALIFIED METHOD
ORDER method takes in evaluation type as input and compares it to another evaluation type object and compares the percent qualified to determine which one is more qualified. If the parameter oject has a lower percent, then false value of 0 is returned. If parameter object has greater percent, then true value of 1 is returned. If both have the same percentQualified, -1 is returned meaning that they are both equal.
*/
CREATE OR REPLACE TYPE BODY evaluation_t AS ORDER MEMBER FUNCTION moreQualified (eval IN evaluation_t) RETURN INTEGER
IS
false_value NUMBER := 0;
true_value  NUMBER := 1;
both_equal NUMBER :=-1;
BEGIN
IF self.percentQualified > eval.percentQualified THEN
RETURN false_value;
ELSIF self.percentQualified < eval.percentQualified THEN
RETURN true_value;
ELSE
RETURN both_equal;
END IF;
END;
/*
METHOD 8: ISQUALIFIED METHOD
Method checks the percentQualified attribute of the object. If the value is greater than 70%, the method returns true value of 1. If the value is below 70%, false value of 0 is returned.
*/
MEMBER FUNCTION isQualified RETURN NUMBER
IS
qualifyingPercent NUMBER := 70;
false_value NUMBER := 0;
true_value  NUMBER := 1;
BEGIN
IF SELF.percentQualified >= qualifyingPercent THEN
RETURN true_value;
ELSE
RETURN false_value;
END IF;
END;
END;
/
/*
METHOD 9: OVERRIDING MEMBERSHIPLENGTH METHOD
Method calculates the number of months between membership start date of user and todays date. This value is used to determine the level of expertise of a user.
*/
CREATE OR REPLACE TYPE BODY recruiter_t AS OVERRIDING MEMBER FUNCTION 
membershipLength RETURN NUMBER
IS
expertiseLevel NUMBER := 0;
yearsOfservice NUMBER := 0;
BEGIN
yearsOfservice := TRUNC(MONTHS_BETWEEN(SYSDATE, SELF.memStart)/12);
IF yearsOfservice <=2 THEN
expertiseLevel := 1;
ELSIF yearsOfservice <=4 THEN
expertiseLevel := 2;
ELSE
expertiseLevel := 3;
END IF;
RETURN expertiseLevel;
END;
/*
METHOD 10: 
Method FINDSALARYINCREASERATE
Method calculates the years of service of a recruiter and returns a number that represents the percentage that the salary should be increased.
*/
MEMBER FUNCTION findsalaryIncreaseRate RETURN NUMBER
IS
increasePercent NUMBER :=0;
yearsOfservice NUMBER :=0;
BEGIN
yearsOfservice := TRUNC(MONTHS_BETWEEN(SYSDATE, SELF.memStart)/12);
IF yearsOfservice BETWEEN 2 AND 5 THEN
increasePercent := 1;
ELSIF yearsOfservice > 5 THEN
increasePercent :=2;
ELSE
increasePercent :=0;
END IF;
RETURN increasePercent;
END;
/*
METHOD 11: FINDINCOMETAXAMOUNT
Method checks the salary of a user and depending on which range the salary falls into, the method calculates a number which represents the tax rate percentage for the recruiter. The taxrate is then multiplied by the salary to return the total amount of tax the recruiter pays.
*/
MEMBER FUNCTION findIncomeTaxAmount RETURN NUMBER
IS
taxRate NUMBER :=0;
BEGIN
IF SELF.salary <= 20000 THEN
taxRate := 5;
ELSIF SELF.salary<=40000 THEN
taxRate :=7;
ELSE
taxRate :=10;
END IF;
RETURN TRUNC(SELF.salary * taxRate/100);
END;
/*
METHOD 12: CALCNETINCOME
Method takes in a number as an input parameter which represents the amount of tax recruiter paid(this number is obtained using the findIncomeTaxAmount() method of recruiter_t type). The method then subtracts the tax amount from the salary of recruiter to get the net income of the recruiter. The net income is returned.
*/
MEMBER FUNCTION calcNetIncome (taxAmount IN NUMBER) RETURN NUMBER
IS
netIncome NUMBER :=0;
BEGIN
netIncome := ROUND(SELF.salary - taxAmount, 2);
RETURN netIncome;
END;
END;
/